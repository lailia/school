package chap02.sec2;

public class CharExam1 {
	
	public static void main(String[] args) {
		char c1 = 'a';
		char c2 = 65;
		char c3 = '가';
		//char c4 = "f";	컴파일 에러 ""는 스트링만 받기 가능
		
		System.out.println("c1 : " + c1);
		System.out.println("c2 : " + c2);
		System.out.println("c3 : " + c3);
		
	}
}
