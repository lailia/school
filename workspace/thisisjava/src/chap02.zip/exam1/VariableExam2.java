package chap02.exam1;

public class VariableExam2 {

	public static void main(String[] args) {
		int hour = 5;
		int minute = 10;
		System.out.println("hour = " + hour + "시간 " + "minute = " + minute + "분");
		int total = (hour * 60) + minute;
		System.out.println("총합 : " + total + "분");
		

	}

}
