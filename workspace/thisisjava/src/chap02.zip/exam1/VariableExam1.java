package chap02.exam1;

public class VariableExam1 {

	public static void main(String[] args) {
		int value = 0;
		int result = value + 10;
		System.out.println(result);

	}

}
