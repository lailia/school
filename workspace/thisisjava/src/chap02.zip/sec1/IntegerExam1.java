package chap02.sec1;

public class IntegerExam1 {

	public static void main(String[] args) {
		int var1 = 0b1011;	//2진수 값 넣기
		int var2 = 0206;	//8진수 값 넣기
		int var3 = 365;		//10진수 값 넣기
		int var4 = 0xB3;	//16진수 값 넣기
		
		System.out.println("var1 : " + var1);
		System.out.println("var2 : " + var2);
		System.out.println("var3 : " + var3);
		System.out.println("var4 : " + var4);

	}

}
